// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
var menu_static = 0;
var news = [
  {
    news_type: 'text',
    news_title: '东北四市市长集体发声回应“投资不过山海关',
    news_source: '中国新闻网',
    news_comont: 7381,
    news_time: '10分钟前'
  },
  {
    news_type:'singleImg',
    news_title:'中印士兵班公湖互郑石头，疑似现场视频曝光',
    images:[
      '/images/news1.jpg'
    ],
    news_source:'环球网',
    news_comont:2381,
    news_time:'15分钟前'
  },
  {
    news_type: 'moreImg',
    news_title: '谁说印度没有准备？看他们30年前在洞朗附近做了什么！',
    images:[
      '/images/news2.jpg',
      '/images/news3.jpg',
      '/images/news4.jpg'
    ],
    news_source: '中国新闻网',
    news_comont: 17381,
    news_time: '20分钟前'
  },
  {
    news_type: 'text',
    news_title: '东北四市市长集体发声回应“投资不过山海关',
    news_source: '中国新闻网',
    news_comont: 7381,
    news_time: '10分钟前'
  },
  {
    news_type: 'singleImg',
    news_title: '中印士兵班公湖互郑石头，疑似现场视频曝光',
    images: [
      '/images/news1.jpg'
    ],
    news_source: '环球网',
    news_comont: 2381,
    news_time: '15分钟前'
  },
  {
    news_type: 'moreImg',
    news_title: '谁说印度没有准备？看他们30年前在洞朗附近做了什么！',
    images: [
      '/images/news2.jpg',
      '/images/news3.jpg',
      '/images/news4.jpg'
    ],
    news_source: '中国新闻网',
    news_comont: 17381,
    news_time: '20分钟前'
  },
];

Page({
    
  data: {
    hid: false,
    menuStatic:menu_static,
    dis:"display_block",
    menu: ['推荐', '热点', '视频', '北京', '社会', '娱乐', '图片', '科技', '汽车', '体育', '财经', '军事', '国际', '时尚', '游戏', '美文'],
    indicatorDots: false,
    autoplay: false,
    interval: 5000,
    duration: 1000,
    indicatorDots:true,
    newsList:news,
    windowHeight: "",
    windowWidth: "",
    page: 0
  },
  onShow:function(){
    wx.getSystemInfo({
      success: (res) => {
        this.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    })
  },
  detail: function(event) {
    wx.navigateTo({
      url: '/pages/information/detail/detail?id=' + event.currentTarget.id
    });
  },
  click_menu:function(event){
      this.menu_static = event.currentTarget.id;
      this.loading();
      this.setData({
         menuStatic:this.menu_static,
         newsList: this.data.newsList.concat(news)
      });
  },
  getMoreNews:function(){
    this.loading();
    this.setData({
      newsList: this.data.newsList.concat(news)
    });
  },
  pullDownRefresh: function (e) {
    console.log("下拉刷新");
    this.setData({
      newsList: news
    });
  },
  pullUpLoad: function (e) {
    var page = this.data.page + 1;
    this.setData({
      page: page
    })
    console.log("上拉加载" + page);
    this.getMoreNews();
  },
  loading: function () {
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 1000
    })
  },
});
