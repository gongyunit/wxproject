// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
var app = getApp();
Page({
  data:{
    userInfo: {},
    y_menus:[
      {title:'消息通知'},
      {title:'浏览历史'},
      {title:'吐槽一下'},
    ],
    x_menus:[
      {title:'收藏',icon:'/images/collection.png'},
      {title:'夜间',icon:'/images/eve.png',classes:'two_side'},
      {title:'设置',icon:'/images/set.png'},
    ],
  },
  onLoad:function(options){
    var that = this;
    app.getUserInfo(function(userInfo){
        console.log(userInfo);
        
        //设置用户信息
        that.setData({
            userInfo:userInfo
        })
    });
  },
})