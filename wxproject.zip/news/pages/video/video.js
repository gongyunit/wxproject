// Created by gongyunit on 2017/6/1
// Copyright © 2017年 工云网络. All rights reserved
var videos = [
  {
    title: '1997年，天王迈克尔杰克逊《Billie Jean》神级版',
    img:'/images/v1.jpg',
    url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
    source: 'RainbowKingdom',
    header: '/images/u1.jpg',
    zan: 192,
    comment: 982
  },
  {
    title: '一个韩红没有发现的音乐天才，高音稳压韩红李玟！',
    img: '/images/v2.jpg',
    url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
    source: ' 男神先锋',
    header: '/images/u2.jpg',
    zan: 592,
    comment: 382
  },
  {
    title: '郑少秋这首歌，至今没有人能成功翻唱过',
    img: '/images/v3.jpg',
    url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
    source: '三次元樱乐',
    header: '/images/u3.jpg',
    zan: 1217,
    comment: 751
  },
  {
    title: '70后80后当年在溜冰场 迪厅听的最嗨的一首歌，你还记得吗？',
    img: '/images/v4.jpg',
    url: 'http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400',
    source: '寻知音',
    header: '/images/u4.jpg',
    zan: 567,
    comment: 8974
  },
];
Page({
  data:{
    videos: videos,
    windowHeight: "",
    windowWidth: "",
    page: 0,
    acviteVId:null,
  },
  onShow: function () {
    wx.getSystemInfo({
      success: (res) => {
        this.setData({
          windowHeight: res.windowHeight,
          windowWidth: res.windowWidth
        })
      }
    })
  },
  getMoreNews: function () {
    this.loading();
    this.setData({
      videos: this.data.videos.concat(videos)
    });
  },
  pullDownRefresh: function (e) {
    console.log("下拉刷新");
    this.setData({
      videos: videos
    });
  },
  pullUpLoad: function (e) {
    var page = this.data.page + 1;
    this.setData({
      page: page
    })
    console.log("上拉加载" + page);
    this.getMoreNews();
  },
  loading: function () {
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 1000
    })
  },
  playVideo: function (event){
    var nowId = event.currentTarget.id;
    var lastId = this.data.acviteVId;
    console.log(nowId, lastId);
    if (lastId && nowId != lastId){
      var videoContext = wx.createVideoContext(lastId);
      videoContext.pause();
    }
    this.setData({
      acviteVId: nowId
    });
  }
})